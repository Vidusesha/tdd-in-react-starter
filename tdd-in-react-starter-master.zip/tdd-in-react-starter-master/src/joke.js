import React from 'react';


export default ({text}) => (
    <div data-testid="joke-text">
        {text}
    </div>
);