# tdd-in-react-starter
Starter repository for lab in software development methodologies 


##### Credits

* [TDD in React](https://www.freecodecamp.org/news/quick-guide-to-tdd-in-react-81888be67c64/)